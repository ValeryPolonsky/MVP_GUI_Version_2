package View;

import algorithms.mazeGenerators.Maze3d;
import algorithms.search.Solution;

public interface View {
	void displayMessage(String message);
	void displayMaze(Maze3d maze);
	void displayCrossSection(Maze3d maze, String axis, int index);
	void displayFilesList(String[]filesList);
	void displaySolution(Solution solution);
	void start();
}
