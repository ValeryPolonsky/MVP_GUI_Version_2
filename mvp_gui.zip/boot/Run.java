package boot;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import Model.MyModel;
import Presenter.Presenter;
import View.MyView;


public class Run {

	public static void main(String[] args) {
		MyModel model=new MyModel();
		
		BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
		PrintWriter writer=new PrintWriter(System.out);
		MyView view=new MyView(reader,writer);
		
		Presenter presenter=new Presenter(model,view);
		view.addObserver(presenter);
		model.addObserver(presenter);
		
		view.start();
		
		
	   /* HashMap<String,Maze3d>mazes=new HashMap<String,Maze3d>();
		HashMap<String,Solution>solutions=new HashMap<String,Solution>();
		
			Maze3dGenerator mg=new MyMaze3dGenerator();
			Solution solution=new Solution();
			Maze3d maze3d=mg.generate(3,3,3);
			solution=testSearcher(new BFS(), new Maze3DSearchable(maze3d));
			
			mazes.put("maze", maze3d);
			solutions.put("maze", solution);
				
			try {
				FileOutputStream fos = new FileOutputStream("solutions.hm");
				GZIPOutputStream gz = new GZIPOutputStream(fos);
				ObjectOutputStream oos = new ObjectOutputStream(gz);
				oos.writeObject(solutions);
				oos.flush();
				oos.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			try {
				FileOutputStream fos = new FileOutputStream("mazes.hm");
				GZIPOutputStream gz = new GZIPOutputStream(fos);
				ObjectOutputStream oos = new ObjectOutputStream(gz);
				oos.writeObject(mazes);
				oos.flush();
				oos.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}*/
	}
	
	//private static Solution testSearcher(Searcher searcher, Searchable searchable){
	//	 Solution solution=searcher.Search(searchable);
		// return solution;
	//}
}
