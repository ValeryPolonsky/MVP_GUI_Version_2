package Presenter;

import Model.Model;
import View.View;

public class DirectoryCommand implements Command {

	Model model;
	View view;
	
	public DirectoryCommand(Model model,View view){
		this.view=view;
		this.model=model;
	}
	
	@Override
	public void doCommand(String[] args) {
		String path="";
		path=args[0];
		for(int i=1;i<args.length;i++)
		{
			path=path+" "+args[i];
		}
		String[]filesList=model.getFilesList(path);
		if(filesList!=null)
			view.displayFilesList(filesList);
		else
			view.displayMessage("!!!There is no such directory!!!\n");
	}
}
