package Presenter;

import Model.Model;
import View.View;

public class SaveMazeCommand implements Command {

	Model model;
	View view;
	
	public SaveMazeCommand(Model model,View view){
		this.model=model;
		this.view=view;
	}
	
	@Override
	public void doCommand(String[] args) {
		
		if(args.length!=2)
		{
			view.displayMessage("\n!!!Wrong number of arguments!!!\n\n");
			return;
		}
		
		if(!model.mazeExists(args[0]))
		{
			view.displayMessage("\n!!!The maze "+args[0]+" doesn't exist!!!\n\n");
			return;
		}
		
		model.saveMaze(args[0], args[1]);
	}

}
