package Presenter;

import java.util.concurrent.Callable;

import Model.Model;
import algorithms.search.Solution;

public class SolveMazeCallable implements Callable<Solution> {

	private Model model;
	private String mazeName;
	private String algorithmName;
	
	public SolveMazeCallable(Model model,String mazeName,String algorithmName)
	{
		this.model=model;
		this.mazeName=mazeName;
		this.algorithmName=algorithmName;
	}
	
	@Override
	public Solution call() throws Exception {
		return model.solveMaze(mazeName, algorithmName);
	}

}
