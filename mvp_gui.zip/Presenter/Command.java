package Presenter;

public interface Command {
	void doCommand(String[]args);
}
