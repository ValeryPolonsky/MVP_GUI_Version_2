package Model;

import algorithms.mazeGenerators.Maze3d;
import algorithms.search.Solution;

public interface Model {
	Maze3d generateMaze(String name,int length,int height,int width);
	void saveMaze(String mazeName,String fileName);
	void loadMaze(String fileName,String mazeName);
	String getMessage();
	Maze3d getMaze(String mazeName);
	int getMazeSize(String mazeName);
	double getFileSize(String fileName);
	String[] getFilesList(String directory);
	Solution solveMaze(String mazeName,String algrorithmName);
	Solution getSolution(String mazeName);
	boolean mazeExists(String mazeName);
	public void loadMazesAndSolutions();
	public void saveMazesAndSolutions();
}
